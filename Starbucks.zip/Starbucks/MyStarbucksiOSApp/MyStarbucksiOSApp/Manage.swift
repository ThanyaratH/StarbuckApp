//
//  Manage.swift
//  MyStarbucksiOSApp
//
//  Created by balabeam on 2/27/17.
//  Copyright © 2017 balabeam. All rights reserved.
//

import UIKit

class Manage: NSObject {
    var ManageBath : String
    var ManageScore : Int
    var ManageExpirationDate : String
    
    init(ManageBath : String, ManageScore : Int, ManageExpirationDate : String) {
        self.ManageBath = ManageBath
        self.ManageScore = ManageScore
        self.ManageExpirationDate = ManageExpirationDate
    }
    func resetRatingScore() -> Void {
        self.ManageScore = 0
    }

}
