//
//  ViewController.swift
//  MyStarbucksiOSApp
//
//  Created by balabeam on 2/27/17.
//  Copyright © 2017 balabeam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let baht1 : Manage = Manage(ManageBath: "Baht", ManageScore: Int(205.00), ManageExpirationDate: "As of 2560-02-22 19:43")
    @IBOutlet weak var lblbaht: UILabel!
    
    @IBOutlet weak var lblscore: UILabel!
    
    @IBOutlet weak var lblexpirationdate: UILabel!
    
    
    @IBAction func btnManage(_ sender: Any) {
        let alertContriller = UIAlertController()
        
        let cancelButton = UIAlertAction (title: "Cancel", style: .cancel, handler: nil)
        
        let refreshbalanceButton = UIAlertAction (title: "Refresh Balance", style: .default) {
            (action) -> Void in
        }
        
        let transactionhistorybutton = UIAlertAction (title: "Transaction History", style: .default){
            (action) -> Void in
        }
        
        
        alertContriller.addAction(cancelButton)
        alertContriller.addAction(refreshbalanceButton)
        alertContriller.addAction(transactionhistorybutton)

        
        
        self.present(alertContriller, animated: true, completion: nil)

        
        
    }
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

