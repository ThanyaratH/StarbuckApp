//
//  ActiveViewController.swift
//  MyStarbucksiOSApp
//
//  Created by balabeam on 2/27/17.
//  Copyright © 2017 balabeam. All rights reserved.
//

import UIKit

class ActiveViewController: UIViewController {
    
    @IBOutlet weak var Active: UIButton!
    
    
    
        @IBAction func activebtn(_ sender: Any) {
    
        let alertContriller = UIAlertController()
        
        let cancelButton = UIAlertAction (title: "Cancel", style: .cancel, handler: nil)
        
        let ActiveButton = UIAlertAction (title: "Active", style: .default) {
            (action) -> Void in
        }
        
        let RedeemedButton = UIAlertAction (title: "Redeemed", style: .default){
            (action) -> Void in
        }
        
        let ExpiredButton = UIAlertAction (title: "Expired", style: .default){
            (action) -> Void in
        }
        
        
        alertContriller.addAction(cancelButton)
        alertContriller.addAction(ActiveButton)
        alertContriller.addAction(RedeemedButton)
        alertContriller.addAction(ExpiredButton)
        
        
        
        self.present(alertContriller, animated: true, completion: nil)
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
